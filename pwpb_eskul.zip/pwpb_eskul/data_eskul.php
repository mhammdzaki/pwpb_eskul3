<?php
// membuat instance
$dataData_eskul=NEW Data_eskul;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<center><h3>Data Eskul</h3>';
$html .='<p>Berikut ini data eskul SMKN 2 Kuningan</p></center>';
$html .='<table class="table table-striped table-hover" border="1" width="100%">
<thead>
<a href="index.php?file=data_eskul&aksi=tambah" class="btn btn-primary" >Tambah Data Eskul  </a>
<th>No.</th>
<th>Kode Eskul</th>
<th>Pilih Eskul</th>
<th>Aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $dataData_eskul->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisData_eskul){
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barisData_eskul->kode_eskul.'</td>
<td>'.$barisData_eskul->pilih_eskul.'</td><td>
<a class="btn btn-primary"
href="index.php?file=data_eskul&aksi=edit&kode_eskul='.$barisData_eskul->kode_eskul.'">Edit</a>
<a class="btn btn-danger"
href="index.php?file=data_eskul&aksi=hapus&kode_eskul='.$barisData_eskul->kode_eskul.'">Hapus</a>
</td>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<center><h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan form </p>';
$html .='<form method="POST"
action="index.php?file=data_eskul&aksi=simpan">';
$html .='<p>Kode Eskul<br/>';
$html .='<input type="text" name="txtEskul"
placeholder="Masukan Kode Eskul" autofocus/></p>';
$html .='<p>Nama Eskul<br/>';
$html .='<input type="text" name="txtPilih"
placeholder="Masukan Nama Eskul" size="30" required/></p>';
$html .='<p><input type="submit" name="tombolSimpan"
value="Simpan"/></p></center>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
'kode_eskul'=>$_POST['txtEskul'],
'pilih_eskul'=>$_POST['txtPilih'],
);
// simpan eskul dengan menjalankan method simpan
$dataData_eskul->simpan($data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=data_eskul&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data eskul
$data_eskul=$dataData_eskul->detail($_GET['kode_eskul']);

    $html =null;
    $html .='<center><h3>Form Tambah</h3>';
    $html .='<p>Silahkan masukan form </p>';
    $html .='<form method="POST"
    action="index.php?file=data_eskul&aksi=update">';
    $html .='<p>Kode Eskul<br/>';
    $html .='<input type="text" name="txtEskul"
    value="'.$data_eskul->kode_eskul.'" placeholder="Masukan Kode Eskul"
    readonly/></p>';
    $html .='<p>Pilih Eskul<br/>';
    $html .='<input type="text" name="txtPilih"
    value="'.$data_eskul->pilih_eskul.'" placeholder="Masukan Nama Eskul"
    size="30" required autofocus/></p>';
    $html .='<p><input type="submit" name="tombolSimpan"
    value="Simpan"/></p></center>';
    $html .='</form>';
    echo $html;
    }
    // aksi tambah data
    else if ($_GET['aksi']=='update') {
    $data=array(
        'Pilih_Eskul'=>$_POST['txtPilih'],
);
$dataData_eskul->update($_POST['txtEskul'],$data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=data_eskul&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='hapus') {
$dataData_eskul->hapus($_GET['kode_eskul']);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=data_eskul&aksi=tampil">';
}
// aksi tidak terdaftar
else {
echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
}
?>