<!DOCTYPE html>
<html>
<head>
 <title>Cetak laporan PDF Di PHP Dan MySQLi</title>
</head>
<body>
 <style type="text/css">
 body{
 font-family: sans-serif;
 }
 table{
 margin: 20px auto;
 border-collapse: collapse;
 }
 table th,
 table td{
 border: 1px solid #3c3c3c;
 padding: 3px 8px;

 }
 a{
 background: blue;
 color: #fff;
 padding: 8px 10px;
 text-decoration: none;
 border-radius: 2px;
 }

    .tengah{
        text-align: center;
    }
 </style>
 <table>
<tr>
<th>id eskul</th>
<th>Nama Siswa</th>
<th>Tempat Lahir</th>
<th>Tanggal Lahir</th>
<th>L/P</th>
<th>Alamat</th>
 </tr>
 <?php 
 // koneksi database
 $koneksi = mysqli_connect("localhost","root","","db_eskul");

 // menampilkan data pegawai
 $data = mysqli_query($koneksi,"select * from eskul");
 while($d = mysqli_fetch_array($data)){
 ?>
 <tr>
 <td style='text-align: center;'><?php echo $d['id_eskul'] ?></td>
 <td><?php echo $d['nama_siswa']; ?></td>
 <td><?php echo $d['tempat_lahir']; ?></td>
 <td><?php echo $d['tanggal_lahir']; ?></td>
 <td><?php echo $d['jenis_kelamin']; ?></td>
 <td><?php echo $d['alamat']; ?> </td>
 </tr>
 <?php 
 }
 ?>
    </table>
    <script>
 window.print();
 </script>
</body>
</html>
