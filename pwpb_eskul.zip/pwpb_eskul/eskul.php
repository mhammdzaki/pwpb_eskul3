<?php
// membuat instance
$dataEskul=NEW Eskul;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<center><h3 Eskul</h3>';
$html .='<p>Berikut ini data    eskul SMKN 2 Kuningan</p></center>';
$html .='<table class="table table-striped table-hover" border="1" width="100%">
<thead>

<a target="_blank" class="btn btn-primary btn-sm"  href="cetak.php">PRINT</a>
<th>No.</th>
<th>id eskul</th>
<th>Nama Siswa</th>
<th>Tempat Lahir</th>
<th>Tanggal Lahir</th>
<th>L/P</th>
<th>Alamat</th>
<th>Aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $dataEskul->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisEskul)

{
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barisEskul->id_eskul.'</td>
<td>'.$barisEskul->nama_siswa.'</td>
<td>'.$barisEskul->tempat_lahir.'</td>
<td>'.$barisEskul->tanggal_lahir.'</td>
<td>'.$barisEskul->jenis_kelamin.'</td>
<td>'.$barisEskul->alamat.'</td>
<td>
<a  class="btn btn-primary"
href="index.php?file=eskul&aksi=edit&id_eskul='.$barisEskul->id_eskul.'">Edit</a>
<a class="btn btn-danger"
href="index.php?file=eskul&aksi=hapus&id_eskul='.$barisEskul->id_eskul.'">Hapus</a>
</td>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<center><h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan form </p>';
$html .='<form method="POST"
action="index.php?file=eskul&aksi=simpan">';
$html .='<p>No eskul<br/>';
$html .='<input type="text" name="txtId_eskul"
placeholder="Masukan No Eskul" autofocus/></p>';
$html .='<p>Nama Lengkap Siswa<br/>';
$html .='<input type="text" name="txtNama_siswa"
placeholder="Masukan Nama Lengkap Siswa" size="30" required/></p>';
$html .='<p>Tempat, Tanggal Lahir<br/>';
$html .='<input type="text" name="txtTempatLahir"
placeholder="Masukan Tempat Lahir" size="30" required/>,';
$html .='<input type="date" name="txtTanggalLahir"
required/></p>';
$html .='<p>Jenis Kelamin<br/>';
$html .='<input class="form-check-input" type="radio" name="txtJenisKelamin"
value="L"> Laki-laki';
$html .='<input class="form-check-input" type="radio" name="txtJenisKelamin"
value="P"> Perempuan</p>';
$html .='<p>Alamat Lengkap<br/>';
$html .='<textarea name="txtAlamat" placeholder="Masukan
alamat lengkap" cols="50" rows="5" required></textarea></p>';
$html .='<p><input type="submit" name="tombolSimpan"
value="Simpan"/></p>';
$html .='</form></center>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
'id_eskul'=>$_POST['txtId_eskul'],
'nama_siswa'=>$_POST['txtNama_siswa'],
'tempat_lahir'=>$_POST['txtTempatLahir'],
'tanggal_lahir'=>$_POST['txtTanggalLahir'],
'jenis_kelamin'=>$_POST['txtJenisKelamin'],
'alamat'=>$_POST['txtAlamat']
);
// simpan eskul dengan menjalankan method simpan
$dataEskul->simpan($data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=eskul&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data eskul
$eskul=$dataEskul->detail($_GET['id_eskul']);
if($eskul->jenis_kelamin =='L') { $pilihL='checked';
    $pilihP =null; }
    else {
    $pilihP='checked'; $pilihL =null; }
    $html =null;
    $html .='<center><h3>Form Tambah</h3>';
    $html .='<p>Silahkan masukan form </p>';
    $html .='<form method="POST"
    action="index.php?file=eskul&aksi=update">';
    $html .='<p>Nomor id eskul<br/>';
    $html .='<input type="text" name="txtId_eskul"
    value="'.$eskul->id_eskul.'" placeholder="Masukan No Eskul"
    readonly/></p>';
    $html .='<p>Nama Lengkap<br/>';
    $html .='<input type="text" name="txtNama_siswa"
    value="'.$eskul->nama_siswa.'" placeholder="Masukan Nama Lengkap"
    size="30" required autofocus/></p>';
    $html .='<p>Tempat, Tanggal Lahir<br/>';
    $html .='<input type="text" name="txtTempatLahir"
    value="'.$eskul->tempat_lahir .'" placeholder="Masukan Tempat
    Lahir" size="30" required/>,';
    $html .='<input type="date" name="txtTanggalLahir"
    value="'.$eskul->tanggal_lahir.'" required/></p>';
    $html .='<p>Jenis Kelamin<br/>';
    $html .='<input type="radio" name="txtJenisKelamin"
    value="L" '.$pilihL.'> Laki-laki';
    $html .='<input type="radio" name="txtJenisKelamin"
    value="P" '.$pilihP.'> Perempuan</p>';
    $html .='<p>Alamat Lengkap<br/>';
    $html .='<textarea name="txtAlamat" placeholder="Masukan
    alamat lengkap" cols="50" rows="5"
    required>'.$eskul->alamat.'</textarea></p>';
    $html .='<p><input type="submit" name="tombolSimpan"
    value="Simpan"/></p></center>';
    $html .='</form>';
    echo $html;
    }
    // aksi tambah data
    else if ($_GET['aksi']=='update') {
    $data=array(
        'nama_siswa'=>$_POST['txtNama_siswa'],
'tempat_lahir'=>$_POST['txtTempatLahir'],
'tanggal_lahir'=>$_POST['txtTanggalLahir'],
'jenis_kelamin'=>$_POST['txtJenisKelamin'],
'alamat'=>$_POST['txtAlamat']
);
$dataEskul->update($_POST['txtId_eskul'],$data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=eskul&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='hapus') {
$dataEskul->hapus($_GET['id_eskul']);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=eskul&aksi=tampil">';
}
// aksi tidak terdaftar
else {
echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
}
?>