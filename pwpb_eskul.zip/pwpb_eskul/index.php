<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet"/>
    <title>Eskul</title>
</head>
<body>
<?php
include('class/Database.php');
include('class/eskul.php');
include('class/data_eskul.php');
?>
<ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="index.php">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="index.php?file=eskul&aksi=tampil">eskul</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="index.php?file=data_eskul&aksi=tampil">data eskul</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="index.php?file=eskul&aksi=tambah">Tambah Eskul</a>
  </li>
</ul>
<hr/>
<?php
if(isset($_GET['file'])){
include($_GET['file'].'.php');
} else {
echo '<h1 align="center">Selamat Datang</h1>';
}
?>
</body>
</html>